document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    const resultsContainer = document.querySelector(".results-container");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const formData = {
            age: document.getElementById("age").value,
            gender: document.getElementById("gender").value,
            blood_type: document.getElementById("blood_type").value,
            medical_condition: document.getElementById("medical_condition").value,
        };

        try {
            const response = await fetch("/similarity", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                throw new Error(`Error: ${response.statusText}`);
            }

            const data = await response.json();
            displayResults(data);
        } catch (error) {
            console.error("Error fetching similarity results:", error);
            resultsContainer.innerHTML = `<p style="color: red;">${error.message}</p>`;
        }
    });

    function displayResults(results) {
        if (results.error) {
            resultsContainer.innerHTML = `<p style="color: red;">Error: ${results.error}</p>`;
            return;
        }

        const tableRows = results
            .map(
                (result) => `
                <tr>
                    <td>${result.Age}</td>
                    <td>${result.Gender}</td>
                    <td>${result["Blood Type"]}</td>
                    <td>${result["Medical Condition"]}</td>
                    <td>${result["Medication"]}</td>
                    <td>${(result.Similarity * 100).toFixed(2)}%</td>
                </tr>
            `
            )
            .join("");

        resultsContainer.innerHTML = `
            <h2>Similar Cases</h2>
            <table>
                <thead>
                    <tr>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Blood Type</th>
                        <th>Medical Condition</th>
                        <th>Medication</th>
                        <th>Similarity (%)</th>
                    </tr>
                </thead>
                <tbody>
                    ${tableRows}
                </tbody>
            </table>
        `;
    }
});
